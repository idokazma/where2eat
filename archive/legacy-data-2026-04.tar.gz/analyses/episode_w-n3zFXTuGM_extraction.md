# Episode Extraction Report: w-n3zFXTuGM

## Episode Metadata

| Field | Value |
|-------|-------|
| **Video ID** | `w-n3zFXTuGM` |
| **Video URL** | https://www.youtube.com/watch?v=w-n3zFXTuGM |
| **Title** | מדברים מהבטן - פרק 148 (מהדורת ממד) |
| **Channel** | מדברים מהבטן (בית הפודיום) |
| **Hosts** | אמית ארונסון, נטע סלונים (יונתן כהן במילואים) |
| **Guests** | חיים כהן (שף/מסעדן), ליאור משיח (שף קונדיטורית) |
| **Context** | Recorded during wartime (October 2023 Israel-Hamas war), episode 148 |
| **Extraction Date** | 2026-03-23 |

## Episode Summary

This is a wartime episode ("מהדורת ממד" - shelter edition) recorded approximately 12 days into the October 2023 war. The hosts discuss:

1. **"Bites of the week"** - Food the hosts have been eating at home during wartime, including deliveries and takeout
2. **Restaurant industry during wartime** - Interview with Chef Haim Cohen about the impossible situation facing restaurateurs (forced to reopen but no customers)
3. **MasterChef Israel finale** - Bar Tzanger's victory and his restaurant Giardino
4. **Noma scandal** - The New York Times expose on workplace abuse at Noma, with firsthand account from Lior Mashiach who did a 4-month stage there
5. **Industry news** - Merluza closing, new restaurant opening rumors at the Mashya hotel space

---

## Restaurant Extractions

### Category 1: Personal Recommendations (Hosts ate there)

---

#### 1. ג'אנגו / Jango Burger

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | ג'אנגו |
| **Corrected Hebrew Name** | ג'אנגו |
| **English Name** | Jango Burger |
| **Google Name** | Jango Burger |
| **Google Place ID** | `ChIJd6FfvPxNHRURKikrdUB3UhQ` |
| **Address** | Hillel ha-Zaken St 12, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0702792, 34.769635 |
| **City** | תל אביב |
| **Cuisine** | המבורגר |
| **Google Rating** | 4.1 (471 reviews) |
| **Price Level** | N/A |
| **Phone** | 03-631-7773 |
| **Website** | https://www.triger.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=1464363947576207658 |
| **Host Opinion** | חיובית מאוד |
| **Mention Type** | Recommendation (personal bite of the week) |
| **In Production DB** | Yes - ID: `7ef1fede-9dc4-448f-bd64-bd3e0100b7c2` |

**Host Quotes (Hebrew):**
> "התל אביבי המוכר ואהוב שיודע לספק את הסחורה מדהים הוא הג'אנגו"
> "ועוד אחד מעולה היה לי קצת ענייני שירותם אפשר אפשר להגיד, אבל אי אפשר לקחת מהם המבורגר מהטובים שאכלתי ואני יש לי אישה עם המבורגר"

**Dishes Mentioned:** המבורגר, קציצה מבשר איכותי, לחמניה רכה
**Special Features:** Works well for delivery; described as "from the genre she likes" - quality meat patty with minimal toppings
**Speaker:** Neta Slonim

---

#### 2. דנבר / Denver

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | הדבר (transcript mangled) |
| **Corrected Hebrew Name** | דנבר |
| **English Name** | Denver |
| **Google Name** | דנוור DENVER |
| **Google Place ID** | `ChIJeR6vCQA5HRURcmz42BvApCc` |
| **Address** | Tchernichovsky St 14, Kefar Sava, 4427107, Israel |
| **Coordinates** | 32.1761392, 34.8928907 |
| **City** | כפר סבא |
| **Cuisine** | המבורגר |
| **Google Rating** | 4.3 (463 reviews) |
| **Price Level** | N/A |
| **Phone** | 077-303-4072 |
| **Website** | https://denver-kfarsaba.web.delivery/ |
| **Google Maps** | https://maps.google.com/?cid=2856619289496546418 |
| **Host Opinion** | חיובית מאוד |
| **Mention Type** | Recommendation (personal bite of the week) |
| **In Production DB** | Yes - ID: `601b4968-6a73-4b74-b98f-7f1b8e8d8e7a` |

**Host Quotes (Hebrew):**
> "ההמבורגר של הדבר בכפר סבא. אני הנדסטי כל ביס יגמר לי. הוא היה מדהים, מופתי, מושלם. תענוג של המבורגר. באמת שפו להם."
> "ההמבורגר שלהם מצוין. אני זכיתי לאכול אותו שם במקום ממש אחרי שהם פתחו."
> "עובר takeי, אבל עובר אותו ממש ממש טוב"

**Dishes Mentioned:** המבורגר
**Special Features:** Also delivers well via takeaway
**Speaker:** Neta Slonim (recommendation), Amit confirms quality

---

#### 3. יאמה גלילות / Yama Glilot

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | יאמה |
| **Corrected Hebrew Name** | ימה גלילות |
| **English Name** | Yama Glilot |
| **Google Name** | yama Glilot ימה גלילות |
| **Google Place ID** | `ChIJ0-_KHkBJHRURrJDAFFkbBX8` |
| **Address** | כביש החוף, Ramat HaSharon, Israel |
| **Coordinates** | 32.149, 34.8057619 |
| **City** | רמת השרון / גלילות |
| **Cuisine** | ישראלי / דגים |
| **Google Rating** | N/A |
| **Price Level** | N/A |
| **Phone** | 077-303-4149 |
| **Website** | Wolt delivery page |
| **Google Maps** | https://maps.google.com/?cid=9152751887114604716 |
| **Host Opinion** | חיובית מאוד |
| **Mention Type** | Recommendation (delivery kit review) |
| **In Production DB** | Yes - ID: `d2d0a7f0-c39b-4b8a-9e5f-8a1c3d2b4e6f` |

**Host Quotes (Hebrew):**
> "יאמה של יובל בן נריה שבעצם פתח בביג בגלילות"
> "כבד קצוץ א ערק קה להכנת כבד קצוץ שמגיעה מושלם עם הכל הכבדים, ביצים קשות, בצל מקורמל, ברנדי להבערה של הכבדים, מלח, פלפל, כל מה שצריך ובדיוק בכמות שצריך, שזה בעיניי הגאונות של הדבר הזה שנקרא יאמה"
> "קיבלתי את הקיט ותוך 10 דקות היה לנו כבד קצוץ חמים עסיסי על בסיס של שומן עוף כזה וואו וואו וואו תענוג"

**Dishes Mentioned:** כבד קצוץ (ערכת הכנה), ערכת המבורגרים, דגים
**Special Features:** Meal kit / delivery concept by Yuval Ben Neriya; previously discussed on the show; genius of portion-sized ingredients
**Speaker:** Amit Aronsohn

---

#### 4. טנא דלי / Tenne Deli

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | טנדלי / טנה דלי |
| **Corrected Hebrew Name** | טנא דלי |
| **English Name** | Tenne Deli |
| **Google Name** | Tenne |
| **Google Place ID** | `ChIJQdqAt8g5HRURkhERCYhQjzs` |
| **Address** | Sasha Argov St 23, Ra'anana, 4334323, Israel |
| **Coordinates** | 32.1931109, 34.8650868 |
| **City** | רעננה |
| **Cuisine** | מעדנייה / אוכל מוכן |
| **Google Rating** | 4.6 (67 reviews) |
| **Price Level** | N/A |
| **Phone** | 073-363-3533 |
| **Website** | https://www.tenne-deli.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=4291737515105259922 |
| **Host Opinion** | חיובית מאוד |
| **Mention Type** | Recommendation (wartime delivery) |
| **In Production DB** | Yes - ID: `93a864f4-bac2-4b1a-8e3f-7c5d6a9b2e1f` |

**Note:** The transcript refers to "טנדלי" which is actually part of the "טעם וצבע" (Taam VaTzeva) catering company. They have a deli/prepared food store in Ramat Aviv.

**Host Quotes (Hebrew):**
> "משלוח מיתנדלי שקיבלתי ביום שישי הקודם ממש כזה ולא ידעתי שהוא יהפוך להיות מנת הקרב שלי לימים הראשונים של מלחמה"
> "הזרוע של טעם וצבע שזה אחת מחברות הקייטרינג הכי גדולות ולדעתי ותיקות ומוערכות מוצלחות בישראל ופתחו לו מזמן חנות נוספת גדולה מאוד מעדניה יפי יפיה ברמת אביב"
> "הדברים ברובם פשוט נהדרים"

**Dishes Mentioned:** מקלובה (סיר לארבעה), קרובית ממולא בבשר טחון ברוטב חמוסט (לימון סלרי), ערקה של בנים ובשר מפורק ומיונז צ'יפוטלה
**Special Features:** Prepared food delivery; part of Taam VaTzeva catering empire; great value for money ("מחירים שפויים באופן מפתיע")
**Speaker:** Amit Aronsohn

---

#### 5. דוכן אילנה דן - שוק לווינסקי / Ilana Dan at Levinski Market

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | אילנה דן בשוק לווינסקי |
| **Corrected Hebrew Name** | דוכן של אילנה דן בשוק לווינסקי |
| **English Name** | Ilana Dan at Levinski Market |
| **Google Name** | Levinski Market |
| **Google Place ID** | `ChIJcdNA6J1MHRUR0mtN6aZ6w4k` |
| **Address** | Levinski St, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0594379, 34.7728971 |
| **City** | תל אביב |
| **Cuisine** | מאפים / לחם |
| **Google Rating** | 4.4 (13,966 reviews) - for the market |
| **Price Level** | N/A |
| **Google Maps** | https://maps.google.com/?cid=9926912860952030162 |
| **Host Opinion** | חיובית מאוד |
| **Mention Type** | Recommendation (new stall discovery) |
| **In Production DB** | Yes - ID: `ba0f9e54-a49c-4b2a-8d1e-6f3c5a7b9d0e` |

**Host Quotes (Hebrew):**
> "אילנה דן שהיא גם אחת מהעופות הטובות בארצנו והמאוד ככה פופולריות בתל אביב היא עובדת עם המון המון מסעדות, מספקת להם לחמים, מחמצות, פוקצ'ות"
> "פתחה דוכן בשוק לווינסקי ביום שישי אחרון, מיד הגעתי לבזוז א פוקצה"
> "ראיתי את התמונה אצלך באינסטגרם וואי אלוהים"

**Dishes Mentioned:** פוקצ'ה, לחם ארטישוק ירושלמי (upcoming)
**Special Features:** New Friday stall by renowned baker Ilana Dan; supplies bread to many top restaurants; follow on Instagram for updates
**Speaker:** Neta Slonim

---

#### 6. המחמצת של חגאי / Hagay Bread (Hagai VeHaLechem)

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | המחמצת של חגאי / והלחם |
| **Corrected Hebrew Name** | חגי והלחם |
| **English Name** | Hagay Bread |
| **Google Name** | Hagay Bread |
| **Google Place ID** | `ChIJzwbbuFs3HRURts5Mf9eW07I` |
| **Address** | Chayim Vital St 25, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0550396, 34.7677815 |
| **City** | תל אביב |
| **Cuisine** | מאפים / לחם מחמצת |
| **Google Rating** | 4.8 (305 reviews) |
| **Price Level** | N/A |
| **Phone** | 03-670-5520 |
| **Website** | https://www.hagaybread.com/ |
| **Google Maps** | https://maps.google.com/?cid=12885808811134996150 |
| **Host Opinion** | חיובית מאוד - "ביסי השנה" (bite of the year) |
| **Mention Type** | Recommendation (bite of the year winner) |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "ביס שזכה אצלי בביסי השנה בעיקרון"
> "המחמצת של חגאי והלחם נאכלת כאן על בסיס יומי משתדלים לפקוד את המקום כמה שיותר מהרגע שהוא נפתח"
> "הלחם הכי טוב שיש הכי טעים שיש משדרג לא משנה מה תשימו על הדבר הזה זה יצא פשוט הכי טעים שיש"

**Dishes Mentioned:** לחם מחמצת
**Special Features:** Won "bite of the year" from the host; eaten daily since opening; described as the best bread available
**Speaker:** Neta Slonim

---

#### 7. רביולון / Raviolon

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | רביולון |
| **Corrected Hebrew Name** | רביולון |
| **English Name** | Raviolon |
| **Google Name** | רביולון |
| **Google Place ID** | `ChIJA2WQcXucAhURZHGLkjSddl0` |
| **Address** | HaNagar St 8, Ashkelon, Israel |
| **Coordinates** | 31.6561626, 34.5877728 |
| **City** | אשקלון |
| **Cuisine** | פסטה |
| **Google Rating** | 4.9 (188 reviews) |
| **Price Level** | N/A |
| **Phone** | 050-214-2082 |
| **Website** | https://www.valuecard.co.il/orders/raviolon |
| **Google Maps** | https://maps.google.com/?cid=6734743141901627748 |
| **Host Opinion** | חיובית |
| **Mention Type** | Recommendation (home cooking with their products) |
| **In Production DB** | Yes - ID: `771307c6-e9d5-4b3a-9c2f-1a4d6b8e0f3c` |

**Host Quotes (Hebrew):**
> "מפעל שנקרא רביולון מפעל שיושב באשקלון מייצרים פסטות באמת מכל הסוגים וטבעוני וכל מיני רביולים ממולאים"
> "אגב בצק נורא נורא דק ונורא נורא אסתטי ויפה"
> "עשינו כתוצאה מכך ערב פסטות לפנטאון. כיף מאוד, טעים מאוד."
> "היה לי איזה הערה קטנה והם ישר כזה לקחו לצומת ליבם שזה מאוד מהמם ומוערך בעיניי"

**Dishes Mentioned:** פסטות קפואות, רביולים ממולאים (טבעוני ומגוון)
**Special Features:** Pasta factory in Ashkelon; very thin and aesthetic dough; vegan options; responsive to feedback; distributed via butcher shops in central Israel
**Speaker:** Neta Slonim

---

#### 8. האלטר פיצה / Alter Pizza

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | האלטר פיצה |
| **Corrected Hebrew Name** | אלטר פיצה |
| **English Name** | Alter Pizza |
| **Google Name** | Alter Pizza |
| **Google Place ID** | `ChIJUarwaABHHRUR8RfU1oCVGxY` |
| **Address** | Natan Alterman St 33, Herzliya, Israel |
| **Coordinates** | 32.1749263, 34.8327441 |
| **City** | הרצליה |
| **Cuisine** | פיצה |
| **Google Rating** | 4.1 (35 reviews) |
| **Price Level** | N/A |
| **Phone** | 054-777-9496 |
| **Google Maps** | https://maps.google.com/?cid=1593031273798178801 |
| **Host Opinion** | חיובית (brief mention) |
| **Mention Type** | Brief mention / local recommendation |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "יש לנו אחת טובה לא רחוק מפה. האלטר פיצה."

**Dishes Mentioned:** פיצה
**Special Features:** Near the hosts' area; brief positive mention
**Speaker:** Amit Aronsohn

---

### Category 2: Industry News / Business Mentions

---

#### 9. נומה / Noma

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | נומה |
| **Corrected Hebrew Name** | נומה |
| **English Name** | Noma |
| **Google Name** | Noma |
| **Google Place ID** | `ChIJpYCQZztTUkYRFOE368Xs6kI` |
| **Address** | Refshalevej 96, 1432 Indre By, Denmark |
| **Coordinates** | 55.6828273, 12.6104808 |
| **City** | קופנהגן, דנמרק |
| **Cuisine** | New Nordic |
| **Google Rating** | 4.6 (2,375 reviews) |
| **Price Level** | 4 (Very Expensive) |
| **Phone** | 32 96 32 97 |
| **Website** | https://noma.dk/ |
| **Google Maps** | https://maps.google.com/?cid=4821926685852557588 |
| **Host Opinion** | שלילית (בהקשר של התחקיר) / מעורבת |
| **Mention Type** | Major news discussion - NYT abuse expose |
| **In Production DB** | Yes - ID: `1481de0b-df92-4b5a-8c3e-9a7f2d1b6e4c` |

**Host Quotes (Hebrew):**
> "התחקיר הגדול מאוד שמתפרסם בניו יורק טיימס בסוף השבוע האחרון על מסעדת נומה בקופנהגגן שבמשך שנים נחשבת למסעדה מהטובות בעולם"
> "תחקיר שמתפרסם בניו יורק טימס בעקבות עמוד אינסטגרם... ובעצם חוסף עדויות אחרי עדויות של טבחים... שעברו מסכת התעללויות אין דרך אחרת לתאר את זה של התעללות פיזית, התעללות נפשית, התעללות"
> "דקירות עם מזלג ברביקיו עד כדי דימום, אגרופים, מסדרי השפלה"
> "פופאפ שכרטיס לארוחה עולה 1500 דולר"

**Context:** Extensive discussion (~15 minutes) about the NYT investigative piece on Rene Redzepi's workplace abuse. Includes interview with Lior Mashiach who staged there in summer 2015 and experienced bullying firsthand. Discussion of LA popup ($1,500/ticket), lost sponsorships (AmEx, Blackbird, Cadillac), and protest planned outside.
**Price Range:** $1,500 per person (LA popup); Very Expensive (Google price_level 4)

---

#### 10. מרלוזה / Merluza

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | מרלוזה |
| **Corrected Hebrew Name** | מרלוזה |
| **English Name** | Merluza / Merloza |
| **Google Name** | מרלוזה | merloza |
| **Google Place ID** | `ChIJ9Zoun59NHRURfo0Fcmygd5A` |
| **Address** | Lilienblum St 24, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0621129, 34.7700262 |
| **City** | תל אביב |
| **Cuisine** | שף ישראלי |
| **Google Rating** | 4.6 (573 reviews) |
| **Price Level** | N/A |
| **Phone** | 077-230-2430 |
| **Website** | http://ontopo.com/he/il/page/55627288 |
| **Google Maps** | https://maps.google.com/?cid=10409965451320069502 |
| **Host Opinion** | עצוב על הסגירה ("זה מבאס מאוד") |
| **Mention Type** | Business news - closing announcement |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "מרלוזה שממש... זה מבאס מאוד"
> "דור אבן בחור מוכשר פלי א בעצם הודיע ממש כזה שנייה לפני שהכל פה התחרבן על הסגירה של מרלוזה"

**Context:** Restaurant by Dor Even announced closure just before the war started. The Lilienblum space is reportedly being taken over by Alexander Sachanovsky (owner of Gaijin) with chefs Gadi and Yonatan (formerly of Kat'ait and Nomi).
**Special Features:** Existed for ~1.5-2 years in current Lilienblum location; original concept existed for 7+ years

---

#### 11. גרציאני / Graziani

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | גרציאני |
| **Corrected Hebrew Name** | גרציאני |
| **English Name** | Graziani |
| **Google Name** | Gratziani |
| **Google Place ID** | `ChIJRayXb7BLHRURIAlZiAYHVfg` |
| **Address** | Yehuda ha-Levi St 123, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0686445, 34.7802287 |
| **City** | תל אביב |
| **Cuisine** | איטלקי / קפה |
| **Google Rating** | 4.5 (648 reviews) |
| **Price Level** | 2 (Moderate) |
| **Phone** | 03-507-0471 |
| **Website** | https://www.facebook.com/grasyanicaffe |
| **Google Maps** | https://maps.google.com/?cid=17894216419065268512 |
| **Host Opinion** | אהדה (נפגע מטילים) |
| **Mention Type** | War damage news |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "גרציאני ברחוב יהודה הלוי שנפגעו קשה מאוד"

**Context:** Mentioned as one of the restaurants hit by missiles in central Tel Aviv during the war.

---

#### 12. הפלור / FLOR

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | הפלור |
| **Corrected Hebrew Name** | פלור |
| **English Name** | FLOR - Cave a Manger |
| **Google Name** | FLOR - Cave a Manger |
| **Google Place ID** | `ChIJadLzWq9LHRURDYPBOG_ZtlE` |
| **Address** | Wilson St 10, Tel Aviv-Yafo, 6522020, Israel |
| **Coordinates** | 32.0672736, 34.7814233 |
| **City** | תל אביב |
| **Cuisine** | בר יין טבעי / אוכל צרפתי |
| **Google Rating** | 4.8 (86 reviews) |
| **Price Level** | N/A |
| **Phone** | 050-872-5210 |
| **Website** | https://www.instagram.com/flor.telaviv/ |
| **Google Maps** | https://maps.google.com/?cid=5888132634550305549 |
| **Host Opinion** | חיובית / אהדה |
| **Mention Type** | War damage news + crowdfunding |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "הפלור שעשו הדסטארט... עליהם ממש לפני שני פרקים, שלושה פרקים"
> "פתחו הדסטארט התחילו צנוע ביקשו 50,000 שק הגיעו ליעד תוך לדעתי יומיים ואז הגדילו את הסך את הסכום של הגיוס ל-200,000 שק כרגע הם עומדים על קצת יותר מ-172,000"
> "בר יין לא גדול כאילו אפילו קצת נשתי כזה יהינות טבעיים ואוכל צרפתי בסוף מצליח לגייס כל כך מהר את הקהילה"

**Context:** Also hit by missiles; launched crowdfunding campaign (HeadStart) - originally asked for 50K NIS, reached goal in 2 days, raised target to 200K, reached 172K. Offers incentives like private dinner for couples at 2,000 NIS donation.
**Special Features:** Natural wine bar; French food; small/intimate venue; strong community support

---

#### 13. ג'רדינו / Giardino

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | ג'רדינו / ג'יארדינו |
| **Corrected Hebrew Name** | ג'יארדינו |
| **English Name** | Giardino |
| **Google Name** | GIARDINO - ג׳יארדינו |
| **Google Place ID** | `ChIJZ3wGVDlNHRUR3O59o86ASaE` |
| **Address** | Louis Pasteur St 2, Tel Aviv-Yafo, 6803602, Israel |
| **Coordinates** | 32.0525099, 34.7530227 |
| **City** | יפו |
| **Cuisine** | שף ישראלי |
| **Google Rating** | 4.2 (22 reviews) |
| **Price Level** | N/A |
| **Phone** | 050-297-6904 |
| **Google Maps** | https://maps.google.com/?cid=11621961938400833244 |
| **Host Opinion** | מעורבת (מאכזבת vs. מוכשר) |
| **Mention Type** | MasterChef discussion / restaurant review |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "בר צנגר שהוא גם השב שמסלת ג'רדינו כוטף את הניצחון"
> "מי שכבר שנתיים וחצי פלוס מוביל מסעדה שאמורה להיות בטופ העירוני אם לא הארצי לא יכול להיות השפע הבא של ישראל"
> "הארוחה שאני למשל אכלתי בג'רדינו לפני בערך שנתיים הייתה ארוחה מאוד מאוד מאכזבת"
> "הטענה הזאת שלו אני לא מגיש כזה מה שכל השפים האחרים מגישים ואז הדבר הראשון שהוא הגיש לי היה תרתר סלק"

**Dishes Mentioned:** תרתר סלק, שיפוד אננס עם קרם אנגלז וטקסטורות אננס (מנת קינוח), פופקורן מחנקה נוזלי
**Special Features:** Located in De Jaffa hotel in Jaffa; Chef Bar Tzanger (MasterChef winner); hotel being purchased by Fattal - may go kosher; received mixed critical praise (Sagi Cohen: "star is born", Bitza Luma Bonne: "big restaurant born in Israel")
**Speaker:** Amit Aronsohn (critical), Neta Slonim (more balanced)

---

#### 14. פו תל אביב / Fu Sushi (Haim Cohen)

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | פו תל אביב |
| **Corrected Hebrew Name** | פו סושי |
| **English Name** | Fu Sushi |
| **Google Name** | Fu Sushi |
| **Google Place ID** | `ChIJ_waSBvVLHRURCCFrOT5v5Y0` |
| **Address** | Dizengoff St 302, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0944673, 34.7767462 |
| **City** | תל אביב |
| **Cuisine** | סושי / אסייתי |
| **Google Rating** | 4.4 (4,439 reviews) |
| **Price Level** | 3 (Expensive) |
| **Phone** | 03-605-1000 |
| **Website** | http://www.fusushi.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=10224700842056556808 |
| **Host Opinion** | ניטרלית (context: wartime discussion) |
| **Mention Type** | Industry discussion - wartime attendance |
| **In Production DB** | Yes - ID: `6abafbca-fb0e-4b7a-8d2f-3e5a1c4b9d6f` |

**Host Quotes (Hebrew):**
> "מותר לשאול כמה אנשים אכלו אתמול בפו תל אביב נניח כמה סועדים היו... בערך 16 17 איש"

**Context:** Mentioned during interview with Haim Cohen about restaurant attendance during war. Only 16-17 diners - illustrating the dire situation.

---

#### 15. מירים / Mirim (Haim Cohen)

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | מירים |
| **Corrected Hebrew Name** | מרים |
| **English Name** | Mirim |
| **Google Name** | מרים - מסעדת שף חיים כהן |
| **Google Place ID** | `ChIJM_U2GABLHRURVAu1V0M4xLU` |
| **Address** | הירקון 5 א, בני ברק, 5120155, Israel |
| **Coordinates** | 32.0963103, 34.8234214 |
| **City** | בני ברק |
| **Cuisine** | שף ישראלי |
| **Google Rating** | 4.1 (136 reviews) |
| **Price Level** | N/A |
| **Phone** | 03-620-9988 |
| **Website** | https://meryam.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=13097655478185691988 |
| **Host Opinion** | אהדה (struggling new restaurant) |
| **Mention Type** | Industry news - new restaurant struggling |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "פתחתי את מסעדת מירים ממש בתחילת השנה בתוך בתוך הכיאוס... וזה לא מסעדה שמצליחה להרוויח מצליחה להרים את הראש אם בכלל והיא נתמכת"

**Context:** Haim Cohen's newest restaurant, opened early 2023, struggling financially due to ongoing crises (post-Oct 7, continuing from COVID impacts).

---

#### 16. גייג'ין / Gaijin Izakaya

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | גייג'ין |
| **Corrected Hebrew Name** | גייג'ין |
| **English Name** | Gaijin Izakaya |
| **Google Name** | Gaijin izakaya |
| **Google Place ID** | `ChIJtT4cRedNHRURcudsoVIVLL0` |
| **Address** | Lilienblum St 29, Tel Aviv-Yafo, 6513308, Israel |
| **Coordinates** | 32.0624191, 34.7712333 |
| **City** | תל אביב |
| **Cuisine** | יפני / איזאקאיה |
| **Google Rating** | 4.1 (298 reviews) |
| **Price Level** | N/A |
| **Phone** | 052-311-9298 |
| **Website** | http://ontopo.com/he/il/page/97659206 |
| **Google Maps** | https://maps.google.com/?cid=13631293616783419250 |
| **Host Opinion** | ניטרלית (business mention) |
| **Mention Type** | Industry news - owner expanding |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "היזם הקולינרי שהוא הבעלים של גייג'ין אלכסנדר סחנובסקי ולפתוח שם מסעדה כנראה עם השפים גדי ויונתן"

**Context:** Owner Alexander Sachanovsky reportedly taking over the Merluza space on Lilienblum to open a new restaurant.

---

#### 17. מאשיה / Mashya

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | מאשיה / משיה |
| **Corrected Hebrew Name** | משייה |
| **English Name** | Mashya |
| **Google Name** | Mashya |
| **Google Place ID** | `ChIJh3glpn5MHRUR6jwTBg3yMK4` |
| **Address** | Mendele Mokher Sfarim St 5, Tel Aviv-Yafo, Israel |
| **Coordinates** | 32.0792599, 34.768714 |
| **City** | תל אביב |
| **Cuisine** | שף ישראלי |
| **Google Rating** | 4.4 (5,330 reviews) |
| **Price Level** | 3 (Expensive) |
| **Phone** | 03-750-0999 |
| **Website** | http://www.mashya.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=12551798299231993066 |
| **Host Opinion** | ניטרלית (industry news) |
| **Mention Type** | Industry news / historical reference |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "מאשיה הייתה אמורה להיות המסעדה השנייה של רפי כהן קראו לה מסעדת חמש בגלגול המקורי שלה אנחנו מדברים על שנת 2013"
> "שם בחמש בהרפתקה הזאת התחילה גם ההידרדרות או הנפילה של רפי ושל רפאל"

**Context:** Discussed in context of rumored return of Rafi Cohen to the Mashya hotel space. Gil Dahan and Mashya may be getting a new culinary direction from Rafi Cohen as consultant. Historical note: originally was supposed to be Rafi Cohen's "Restaurant 5" in 2013, which led to his downfall.
**Special Features:** Rumor that Rafi Cohen may return as culinary consultant - described as "cosmic karma" given the history

---

### Category 3: Historical / Brief References

---

#### 18. נומי / Nomi (Kfar Monash)

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | נומי |
| **Corrected Hebrew Name** | נומי |
| **English Name** | Nomi |
| **Google Name** | NOMI |
| **Google Place ID** | `ChIJ5WsntJ0VHRURYcYuqjsEQGk` |
| **Address** | נומי, כפר מונש, 4287500, Israel |
| **Coordinates** | 32.3446197, 34.9115447 |
| **City** | כפר מונש |
| **Cuisine** | שף ישראלי |
| **Google Rating** | 4.2 (1,637 reviews) |
| **Price Level** | N/A |
| **Phone** | 09-774-0635 |
| **Website** | https://www.facebook.com/nomi.monash/ |
| **Google Maps** | https://maps.google.com/?cid=7584066426796688993 |
| **Host Opinion** | ניטרלית |
| **Mention Type** | Historical reference (chefs' background) |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "גדי בור דון שהיו פעם בקטעית ואחר כך היו בנומי בכפר מונש"

**Context:** Mentioned as previous workplace of chefs Gadi and Yonatan who are rumored to open the new restaurant in the Merluza space.

---

#### 19. רפאל / Rafael

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | רפאל |
| **Corrected Hebrew Name** | רפאל |
| **English Name** | Rafael |
| **Google Place ID** | N/A (closed/repurposed) |
| **City** | תל אביב |
| **Cuisine** | שף ישראלי |
| **Host Opinion** | ניטרלית (historical) |
| **Mention Type** | Historical reference |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "המסעדה הבאה שלו אחרי רפאל... שם בעצם הדברים התחילו קצת להידרדר"

**Context:** Rafi Cohen's original flagship restaurant. Mentioned in context of the story of his downfall when he tried to open a second restaurant (Hamesh/Mashya).

---

#### 20. קטעית / Kat'ait

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | קטעית |
| **Corrected Hebrew Name** | קטעית |
| **English Name** | Kat'ait |
| **Google Place ID** | N/A (historical reference, may be closed) |
| **City** | לא צוין |
| **Host Opinion** | ניטרלית |
| **Mention Type** | Historical reference (chefs' background) |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "גדי בור דון שהיו פעם בקטעית"

**Context:** Brief mention as former workplace of chefs Gadi and Yonatan.

---

#### 21. טעם וצבע / Taam VaTzeva (Catering)

| Field | Value |
|-------|-------|
| **Hebrew Name (transcript)** | טעם וצבע |
| **Corrected Hebrew Name** | טעם וצבע |
| **English Name** | Taam VaTzeva / Deli Flavor and Color |
| **Google Name** | Deli flavor and color |
| **Google Place ID** | `ChIJZ4NTIHETHRURg9_x21EagUo` |
| **Address** | Gesher HaEts 1-9, Israel |
| **Coordinates** | 32.4047317, 34.9002799 |
| **Cuisine** | קייטרינג |
| **Google Rating** | 4.6 (302 reviews) |
| **Price Level** | 2 (Moderate) |
| **Phone** | 04-622-0365 |
| **Website** | http://www.taam-vatzeva.co.il/ |
| **Google Maps** | https://maps.google.com/?cid=5368601169687076739 |
| **Host Opinion** | חיובית |
| **Mention Type** | Parent company of Tenne Deli |
| **In Production DB** | No |

**Host Quotes (Hebrew):**
> "אנשי טעם וצבע שזה אחת מחברות הקייטרינג הכי גדולות ולדעתי ותיקות ומוערכות מוצלחות בישראל"

**Context:** Mentioned as the parent company behind Tenne Deli. One of the biggest, oldest, and most successful catering companies in Israel.

---

## Summary Statistics

| Metric | Count |
|--------|-------|
| **Total restaurants mentioned** | 21 |
| **Strong recommendations** | 8 (Jango, Denver, Yama, Tenne Deli, Ilana Dan/Levinski, Hagai Bread, Raviolon, Alter Pizza) |
| **Industry news** | 7 (Noma, Merluza, Graziani, FLOR, Giardino, Mirim, Gaijin) |
| **Historical references** | 5 (Mashya, Nomi, Rafael, Kat'ait, Taam VaTzeva) |
| **Business mention (Haim Cohen interview)** | 1 (Fu/Pu Tel Aviv) |
| **Already in production DB** | 8 (Jango, Denver, Yama, Raviolon, Levinski, Fu/Pu, Noma, Tenne Deli) |
| **New (not in production DB)** | 13 |
| **Israeli restaurants** | 20 |
| **International restaurants** | 1 (Noma, Copenhagen) |
| **Tel Aviv area** | 12 |
| **Central Israel (other)** | 5 (Kfar Saba, Herzliya, Ra'anana, Ramat HaSharon, Bnei Brak) |
| **South** | 1 (Ashkelon) |
| **North** | 1 (Taam VaTzeva HQ) |
| **Abroad** | 1 (Copenhagen) |

### Host Opinions Breakdown

| Opinion | Count |
|---------|-------|
| Very positive | 7 |
| Positive | 2 |
| Mixed | 1 (Giardino) |
| Neutral / Industry context | 8 |
| Negative context (war damage) | 2 (Graziani, FLOR) |
| Negative context (scandal) | 1 (Noma) |

### Cuisine Distribution

| Cuisine | Count |
|---------|-------|
| המבורגר | 2 |
| שף ישראלי | 6 |
| לחם / מאפים | 2 |
| פסטה | 1 |
| פיצה | 1 |
| בר יין / צרפתי | 1 |
| סושי / אסייתי | 1 |
| יפני | 1 |
| איטלקי / קפה | 1 |
| מעדנייה / אוכל מוכן | 1 |
| קייטרינג | 1 |
| New Nordic | 1 |
| לא צוין | 2 |

### Key Restaurants to Add to Production DB

The following 13 restaurants are mentioned but NOT yet in the production database:

1. **חגי והלחם** (Hagay Bread) - Strong recommendation, "bite of the year"
2. **אלטר פיצה** (Alter Pizza) - Brief positive mention
3. **מרלוזה** (Merluza) - Closing news (may not be relevant to add)
4. **גרציאני** (Graziani) - War damage news
5. **פלור** (FLOR) - War damage + crowdfunding news
6. **ג'יארדינו** (Giardino) - MasterChef winner's restaurant, mixed review
7. **מירים** (Mirim) - Haim Cohen's new restaurant, industry news
8. **גייג'ין** (Gaijin) - Owner expanding, industry news
9. **משייה** (Mashya) - Historical/industry news
10. **נומי** (Nomi) - Historical reference
11. **רפאל** (Rafael) - Historical reference (likely closed)
12. **קטעית** (Kat'ait) - Historical reference
13. **טעם וצבע** (Taam VaTzeva) - Catering company, parent of Tenne Deli

### Priority additions (recommended with full data):
1. **חגי והלחם** - Highest priority, strong recommendation with excellent Google rating (4.8)
2. **פלור** - Excellent Google rating (4.8), meaningful story
3. **ג'יארדינו** - MasterChef winner, notable restaurant
4. **מרלוזה** - High Google rating (4.6), notable closing
5. **גרציאני** - Good Google rating (4.5), war impact story
