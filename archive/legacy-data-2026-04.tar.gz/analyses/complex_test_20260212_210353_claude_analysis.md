# CLAUDE Restaurant Analysis Results

**Generated:** 2026-02-12 21:03:53
**Video ID:** complex_test
**LLM Provider:** claude (claude_error)
**Model:** claude-sonnet-4-20250514

## Episode Summary
שגיאה בניתוח CLAUDE של הסרטון complex_test: "Could not resolve authentication method. Expected either api_key or auth_token to be set. Or for one of the `X-Api-Key` or `Authorization` headers to be explicitly omitted"

## Restaurants Found (0)

## Food Trends

- שגיאה בניתוח
- שגיאה: "Could not resolve authentication method. Expected either api_key or auth_token to be set. Or for one of the `X-Api-Key` or `Authorization` headers to be explicitly omitted"

